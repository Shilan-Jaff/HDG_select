-For this softwre to work properly make sure of the following requirements

 MATLAB compiler, the version of MATLAB runtime compiler which is used by the current sofrware is R2016a
which does not require to have MATLAB license and can be found freely at following link
 https://www.mathworks.com/products/compiler/matlab-runtime.html




