For this software to work properly please make sure you have the appropriate MATLAB compiler which is R2017b.
 Alternateviley, you can dowload it from the link below 
https://www.mathworks.com/products/compiler/matlab-runtime.html 
Then you can directly install the HDG-select.exe on your machine.





